package com.lb.mylibrary

import android.util.Log

class PublicClass {
    fun foo() {
        Log.d("AppLog", "PublicClass foo")
        Log.e("AppLog", "PublicClass foo")
        InternalClass().foo()
        JavaInternalClass().foo()
    }
}
