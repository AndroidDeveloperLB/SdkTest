package com.lb.mylibrary;

import android.util.Log;

class JavaInternalClass {
    public void foo() {
        Log.d("AppLog", "JavaInternalClass foo");
        Log.e("AppLog", "JavaInternalClass foo");
    }
}
