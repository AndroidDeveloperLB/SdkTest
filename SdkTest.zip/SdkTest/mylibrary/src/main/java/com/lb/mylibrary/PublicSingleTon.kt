package com.lb.mylibrary

import android.util.Log

object PublicSingleTon {
    fun foo(){
        Log.d("AppLog", "PublicSingleTon foo")
        Log.e("AppLog", "PublicSingleTon foo")
    }
}
