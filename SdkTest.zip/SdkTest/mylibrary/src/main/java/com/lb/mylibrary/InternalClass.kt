package com.lb.mylibrary

import android.util.Log

internal class InternalClass {
    fun foo() {
        Log.d("AppLog", "InternalClass foo")
        Log.e("AppLog", "InternalClass foo")
    }
}
