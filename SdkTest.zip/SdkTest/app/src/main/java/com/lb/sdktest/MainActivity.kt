package com.lb.sdktest

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.lb.mylibrary.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        PublicSingleTon.foo()
        PublicClass().foo()
        Foo.foo()
//        PublicSingleTon.foo()
//        PublicClass().foo()
//        Foo.foo()
    }
}
