package com.lb.sdktest;

class Foo {
    public static void foo(){
//        new InternalClass().foo();
    }
}
